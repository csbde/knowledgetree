site.ui=new function(){
	this.defaults.createButton=function(){
		var buttonSpanAttributes={
			id:
		}
	}
	
	
	createButton=function(text,options){
		//<span id="" onclick="events.trigger('panel.document.edit.show')" class="fg-button ui-state-default ui-priority-primary ui-corner-all" style="width: 100px; border: 1px solid #BBBBBB; padding:2px; cursor:pointer;"><span style="display: inline; padding-right: 15px;" class="ui-icon ui-icon-pencil"/></span><span style="padding-left:5px;">Edit</span></span>
	}
}